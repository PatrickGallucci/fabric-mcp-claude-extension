This directory will contain the compiled executables after running the build script.
